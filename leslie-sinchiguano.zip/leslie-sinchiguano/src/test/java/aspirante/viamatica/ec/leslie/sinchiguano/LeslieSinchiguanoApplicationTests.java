package aspirante.viamatica.ec.leslie.sinchiguano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeslieSinchiguanoApplicationTests {

	@Test
	void contextLoads() {
	}

}
